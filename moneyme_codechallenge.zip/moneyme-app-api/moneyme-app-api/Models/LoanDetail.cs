﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace moneyme_app_api.Models
{
    public class LoanDetail
    {
        [Key]
        public int ID { get; set; }
        public virtual LoanProfile loanProfile { get; set; }
        public string redirectUrl { get; set; }
        public decimal repaymentAmount { get; set; }
        public decimal totalRepayments { get; set; }
        public decimal interestAmount { get; set; }
    }
}


