﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using moneyme_app_api.Models;


namespace moneyme_app_api
{
    public class LoanDBContext : DbContext
    {
        public LoanDBContext(DbContextOptions<LoanDBContext> options) : base(options)
        {

        }

        public DbSet<Models.LoanDetail> LoanDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LoanDetail>()
                .HasOne(p => p.loanProfile);
            
            base.OnModelCreating(modelBuilder);
        }
    }
}