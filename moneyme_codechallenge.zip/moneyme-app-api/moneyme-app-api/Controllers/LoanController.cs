﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using moneyme_app_api.Models;

namespace moneyme_app_api.Controllers
{
    [Produces("application/json")]
    [Route("api/loans")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        readonly LoanDBContext _context;
        public LoanController(LoanDBContext loanDBContext) 
        {
            this._context = loanDBContext;

            Initialize();
        }

        private void Initialize()
        {
            if (_context.LoanDetails.Any())
            {
                return;
            }

            _context.LoanDetails.AddRange(
                new LoanDetail()
                {
                    ID = 1,
                    loanProfile = new LoanProfile()
                    {
                        ProfileID = 1,
                        Title = "Mr.",
                        FirstName = "John",
                        LastName = "Doe",
                        Mobile = "0422111333",
                        Email = "layton@flower.com.au",
                        AmountRequired = 5000,
                        Term = 2
                    },
                    interestAmount = decimal.Zero,
                    repaymentAmount = decimal.Zero,
                    redirectUrl = string.Empty
                }
             );

            _context.SaveChanges();
        }

        [HttpGet("{quoteId}")]
        public LoanDetail Get([FromRoute] int quoteId)
        {
            return _context.LoanDetails.Include(p => p.loanProfile).FirstOrDefault(l => l.ID == quoteId);
        }

        public IEnumerable<LoanDetail> Get()
        {
            return _context.LoanDetails.Include(p => p.loanProfile);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody]LoanDetail loanDetail)
        {
            if(loanDetail.ID == 0)
            {
                int newID = _context.LoanDetails.Include(p => p.loanProfile).Select(x => x.ID).Max() + 1;
                loanDetail.ID = newID;
                _context.LoanDetails.Add(loanDetail);
            }
            else
            {
                _context.LoanDetails.Update(loanDetail);
            }

            await _context.SaveChangesAsync();
            return Ok(loanDetail);

        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> NewProfile([FromBody]LoanProfile loanProfile)
        {
            int newID = _context.LoanDetails.Include(p => p.loanProfile).Select(x => x.ID).Max() + 1;

            LoanDetail loanDetail = new LoanDetail()
            {
                ID = newID,
                interestAmount = decimal.Zero,
                repaymentAmount = decimal.Zero,
                redirectUrl = string.Empty,
                loanProfile = new LoanProfile()
                {
                    ProfileID = newID,
                    Title = loanProfile.Title,
                    FirstName = loanProfile.FirstName,
                    LastName = loanProfile.LastName,
                    Mobile = loanProfile.Mobile,
                    Email = loanProfile.Email,
                    AmountRequired = loanProfile.AmountRequired,
                    Term = loanProfile.Term
                }
            };
            
            _context.LoanDetails.Add(loanDetail);

            await _context.SaveChangesAsync();
            return Ok(loanDetail);
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> UpdateLoan([FromBody]LoanDetail loanDetail)
        {
            _context.LoanDetails.Attach(loanDetail);
            
            _context.Entry(loanDetail).Property(p => p.repaymentAmount).IsModified = true;
            _context.Entry(loanDetail).Property(p => p.totalRepayments).IsModified = true;
            _context.Entry(loanDetail).Property(p => p.interestAmount).IsModified = true;
            await _context.SaveChangesAsync();

            return Ok(loanDetail);
        }
    }
}