MoneyMe

How to launch the app
1. Open the the moneyme-app folder in Visual Studio Code
2. Go to the Terminal Window
3. Enter "npm install" to install all dependency packages and node modules
4. Enter "ng serve --open" to launch the app
Note: Since there is time, I took the opportunity to create the app using Angular web framework to gain new skills and learnings at the same time because I am much more inclined into .Net and currently using React framework.

How to launch the api for the 1st time;
1. Open the moneyme-app-api solution in Visual Studio .Net
2. Right click the solution in solution explorer and click Restore Nuget Packages 
3. Go to the Package and enter "Install-Package Microsoft.EntityFrameworkCore.InMemory" 
4. Build and Run as moneyme-app-api to launch the web-api
Note: the web-api uses Ef-Core In-Memory Database so all data are reset when the api is closed. There is one loan detail/profile data with id-1 initialized.


https://<localhost>/api/loans		<-- get all loans
https://<localhost>/api/loans/<id>	<-- get loan id 
https://<localhost>/api/loans		<-- post (add/update) loan (invoked when calculating loan and saving info and finance details)
https://<localhost>/api/loans/updateloan  <-- post (invoked when applying loan)
https://<localhost>/api/loans/newprofile  <-- post (accepts the loan profile json data that will redirect to the loan calculate loan page) 

http://<localhost>/quote-calc		<-- landing page loads the calculate quote form the data saved/request sent to the api
http://<localhost>/quote-calc/<id>	<-- enter id of the loan profile/id that you want to load the



