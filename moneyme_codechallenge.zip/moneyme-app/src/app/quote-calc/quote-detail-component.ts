
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { QuoteCalcService } from './quote-calc-service'
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router'

@Component({
    selector: 'quote-detail',
    templateUrl: './quote-detail-component.html',
    styleUrls: ['./quote-detail-component.css']
})


export class QuoteDetailComponent implements OnInit { 

    quoteID
    profileId: number
    quoteInfo = {} as any
    quoteDetailForm: FormGroup
    fullName: string
    repaymentAmount: string
    totalRepayments: number
    interestAmount: number
    response: any

    constructor(private service: QuoteCalcService, private route: Router, private activRoute: ActivatedRoute) {

    }

    async ngOnInit() {
        this.quoteID = this.activRoute.snapshot.paramMap.get('quoteId')
        this.profileId = Number(this.quoteID)
        console.log(this.quoteID)

        this.response = this.service.getLoanQuote(this.quoteID)
        await this.service.getLoanQuote(this.quoteID).then(res => {
            this.response = res        
        })
        
        this.quoteInfo = this.response.loanProfile
        //this.repaymentAmount = this.response.repaymentAmount
        
        this.fullName = this.quoteInfo.title + " " + this.quoteInfo.firstName + " " + this.quoteInfo.lastName
 
        this.quoteDetailForm = new FormGroup({
            fullName: new FormControl({value:"", disabled: true}),
            mobile: new FormControl({value:"", disabled: true}),
            email: new FormControl({value:"", disabled: true}),
            amountRequired: new FormControl({value:"", disabled: true}),
            repaymentAmount: new FormControl({value:"", disabled: true}),
            profileId: new FormControl()
        })

        this.computeAmounts(this.quoteInfo.amountRequired)

    }

    toggleInfo(btn) {
        console.log(btn.textContent)

        if (btn.textContent == 'Edit') {
            btn.textContent = 'Save'
            this.quoteDetailForm.controls["fullName"].enable()
            this.quoteDetailForm.controls["mobile"].enable()
            this.quoteDetailForm.controls["email"].enable()
        }
        else {
            btn.textContent = 'Edit'
            this.quoteDetailForm.controls["fullName"].disable()
            this.quoteDetailForm.controls["mobile"].disable()
            this.quoteDetailForm.controls["email"].disable()
            this.saveInfo()
        }
    }

    toggleFinance(btn) {
        if (btn.textContent == 'Edit') {
            btn.textContent = 'Save'
            this.quoteDetailForm.controls["amountRequired"].enable()
            this.quoteDetailForm.controls["repaymentAmount"].enable() 
        }
        else {
            btn.textContent = 'Edit'
            this.quoteDetailForm.controls["amountRequired"].disable()
            this.quoteDetailForm.controls["repaymentAmount"].disable()
            this.saveInfo()
        }        
    }

    onKeyAmount(val) {
        console.log(val)
        this.computeAmounts(val)
    }

    computeAmounts(val) {
        this.repaymentAmount = Math.abs(this.service.PMT(.065 / 12, 12 * 2, Number(val), 0, 0)).toFixed(2)

        this.totalRepayments = Number(val) + Number(this.repaymentAmount)  + 300

        let installment: number = (Number(this.repaymentAmount) * 24) - Number(val)
        this.interestAmount = installment
    }

    saveInfo() {
        console.log("form.... " + JSON.stringify(this.quoteDetailForm.value))

        let names =  this.fullName.split(" ");
        let loanDetail: any = {
            id: Number(this.quoteID),
            loanProfile: {
                profileId: Number(this.profileId),
                title: names[0],
                firstName: names[1],
                lastName: names[2],
                mobile: this.quoteDetailForm.controls["mobile"].value,
                email: this.quoteDetailForm.controls["email"].value,
                amountRequired: this.quoteDetailForm.controls["amountRequired"].value
            }          
        }

        console.log("saveInfo... " + loanDetail)

        this.service.postCalculateQuote(loanDetail)
    }

    submitApplication(detail) {
        console.log("form..." + JSON.stringify(detail))

        let loanDetail: any = {
            id: Number(this.quoteID),            
            repaymentAmount: Number(this.repaymentAmount),
            totalRepayments: this.totalRepayments,
            interestAmount: this.interestAmount,
            fullName: this.fullName
        }

        console.log("apply... " + JSON.stringify(loanDetail))

        this.service.updateloan(loanDetail)
        this.route.navigate(['quote-success', JSON.stringify(loanDetail)]);
    }

}