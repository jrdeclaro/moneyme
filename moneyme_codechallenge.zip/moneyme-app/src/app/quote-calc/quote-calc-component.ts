import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { QuoteCalcService } from './quote-calc-service'
import { Router, ActivatedRoute } from '@angular/router';

interface PrefixName {
    value: string;
    viewValue: string;
}

@Component({
    selector: 'quote-calc',
    templateUrl: './quote-calc-component.html',
    styleUrls: ['./quote-calc-component.css']
})


export class QuoteCalcComponent implements OnInit { 

    prefixNames: PrefixName[] = [
        {value: 'Mr.', viewValue: 'Mr.'},
        {value: 'Ms.', viewValue: 'Ms.'},
        {value: 'Mrs.', viewValue: 'Mrs.'},
        {value: 'Dr.', viewValue: 'Dr.'},
        {value: 'Atty.', viewValue: 'Atty.'}
    ];

    loanProfile = {} as any
    redirectUrl: string = ""
    quoteCalcForm: FormGroup
    response: any
    profileId: number = 1

    constructor(private service: QuoteCalcService, private router: Router, private activeRoute: ActivatedRoute) { 

    }

    async ngOnInit() {

        let paramId: any = this.activeRoute.snapshot.paramMap.get('profileId')
        console.log("param.... " + paramId)
        this.profileId = paramId == null ? 1 : Number(paramId)

        //let resp: any = this.service.getLoanQuote(this.quoteId)
        let resp: any
        await this.service.getLoanQuote(this.profileId).then((res => {
            console.log("res.. " + JSON.stringify(res))
            resp = res        
        }))

        console.log("profile... " + resp.loanProfile)

        this.loanProfile = resp.loanProfile
        this.redirectUrl = resp.redirectUrl

        this.quoteCalcForm = new FormGroup({
            title: new FormControl(),
            firstName: new FormControl(),
            lastName: new FormControl(),
            email: new FormControl(),
            mobile: new FormControl(),
            amountRequired: new FormControl(),
            profileId: new FormControl()
        });
    }

    async onSubmit(quoteForm) {

        let loanDetail: any = {
            id: quoteForm.profileId,
            loanProfile: quoteForm
        }
        console.log("calc... " + JSON.stringify(loanDetail))

        let response: any = await this.service.postCalculateQuote(loanDetail)
        console.log("response... " + response)
        this.router.navigate(['quote-detail', this.profileId]);
    }

}