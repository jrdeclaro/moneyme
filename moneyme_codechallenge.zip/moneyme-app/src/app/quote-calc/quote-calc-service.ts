import { Injectable } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'

/*
let responseData: any = {
    loanProfile: {
        amountRequired: "5000",
        term: 2,
        title: "Mr.",
        firstName: "John",
        lastName: "Doe",
        mobile: "0422111333",
        email: "layton@flower.com.au"
    },
    redirectUrl: "routelink",
    repaymentAmount: 56.15
}*/

export interface LoanProfile {
    profileID: number,
    amountRequired: number,
    term: number,
    title: string,
    firstName: string,
    lastName: string,
    mobile: string,
    email: string
}

export interface MediaItem {
    id: 3,
    loanProfile: LoanProfile,
    redirectUrl: string,
    repaymentAmount: number,
    totalRepayments: number,
    interestAmount: number
}

const _url = "https://localhost:5001/api/loans/"


@Injectable()
export class QuoteCalcService {

    headers={
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    }

    constructor(private http: HttpClient) {

    }

    saveLoanProfile(postData) {
        //return responseData as any
        this.http.post(_url + 'newprofile', postData).subscribe(res => {
            console.log(res)
        })
    }

    getLoanQuote(quoteID) : Promise<any> {        
        //return this.http.get(`${_url}${quoteID}`);
        return this.http.get(`${_url}${quoteID}`).toPromise();
    }

    async postCalculateQuote(postData) {
        /*this.http.post(_url, postData).subscribe(res => {
            console.log(res)
        })*/
        return await this.http.post(_url, postData, this.headers).toPromise()
    }

    updateloan(postData) {
        //return responseData as any
        this.http.post(_url + "updateloan", postData).subscribe(res => {
            console.log(res)
        })
    }    

    PMT(rate_per_period: number, number_of_payments: number, present_value: number, future_value: number, type: number) {
        if(rate_per_period != 0.0) {
            var q = Math.pow(1 + rate_per_period, number_of_payments);
            return -(rate_per_period * (future_value + (q * present_value))) / ((-1 + q) * (1 + rate_per_period * (type)));
    
        } else if(number_of_payments != 0.0){
            return -(future_value + present_value) / number_of_payments;
        }
    
        return 0;
    }    
    
}
