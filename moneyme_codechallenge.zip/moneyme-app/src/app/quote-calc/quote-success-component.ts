import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Route } from '@angular/router'

@Component({
    selector: 'quote-success',
    templateUrl: './quote-success-component.html',
    styleUrls: ['./quote-success-component.css']
})

export class QuoteSuccessComponent implements OnInit { 

    repaymentAmount: number
    totalRepayments: number
    fullName: string
    constructor(private activeRoute: ActivatedRoute) {
        
    }

    async ngOnInit() {
        let loan: any
        await this.activeRoute.paramMap.subscribe(param => {
            loan = JSON.parse(param.get('quoteId'));
            console.log("success.... " + loan)
        })

        this.repaymentAmount = Number(loan.repaymentAmount)
        this.fullName = loan.fullName
        this.totalRepayments = Number(loan.totalRepayments)

        console.log("transfered...." + this.repaymentAmount + this.fullName + this.totalRepayments)

    }
}
