import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuoteCalcComponent } from './quote-calc/quote-calc-component'
import { QuoteDetailComponent } from './quote-calc/quote-detail-component'
import { QuoteSuccessComponent } from './quote-calc/quote-success-component'

const routes: Routes = [
  {
    path: "",
    redirectTo: "quote-calc",
    pathMatch: "full"
  },
  {
    path: "quote-calc",
    component: QuoteCalcComponent
  },
  {
    path: "quote-calc/:profileId",
    component: QuoteCalcComponent
  },  
  {
    path: "quote-detail",
    component: QuoteDetailComponent
    
  },
  {
    path: "quote-detail/:quoteId",
    component: QuoteDetailComponent
    
  },
  {
    path: "quote-success/:quoteId",
    component: QuoteSuccessComponent
  }    
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {
  
}
