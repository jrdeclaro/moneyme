import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { QuoteCalcService } from './quote-calc/quote-calc-service'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { QuoteCalcComponent } from './quote-calc/quote-calc-component'
import { QuoteDetailComponent } from './quote-calc/quote-detail-component'
import { QuoteSuccessComponent } from './quote-calc/quote-success-component'

import { LoanMaterialModule } from './app.material-module'


@NgModule({
  declarations: [
    AppComponent,
    QuoteCalcComponent,
    QuoteDetailComponent,
    QuoteSuccessComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule, ReactiveFormsModule,
    LoanMaterialModule,
    HttpClientModule
  ],
  providers: [QuoteCalcService],
  bootstrap: [AppComponent]
})

export class AppModule { 

}
